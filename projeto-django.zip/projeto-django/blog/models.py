from django.db import models

# Create your models here.
class user(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)

class ufs(models.Model):
    id_uf = models.AutoField(primary_key=True)
    nome_uf = models.CharField(max_length=30)
    sigla_uf = models.CharField(max_length=2)

class cidades(models.Model):
    id_cidade = models.AutoField(primary_key=True)
    nome_cidade = models.CharField(max_length=50)
    id_uf = models.ForeignKey(ufs, on_delete=models.CASCADE)

class enderecos(models.Model):
    id_endereco = models.AutoField(primary_key=True)
    id_cidade = models.ForeignKey(cidades,on_delete=models.CASCADE)
    logradouro = models.CharField(max_length=150)
    numero = models.IntegerField(max_length=8)
    cep = models.IntegerField(max_length=10)
    bairro = models.CharField(max_length=80)
    complemento = models.CharField(max_length=60)
    observacoes = models.TextField() 

class contas(models.Model):
    id_conta = models.AutoField(primary_key=True)
    tp_conta = models.CharField(max_length=30)
    id_banco = models.IntegerField
    banco = models.CharField(max_length=50)
    conta = models.IntegerField()
    agencia = models.IntegerField()
    operacao = models.IntegerField()
   
class pessoas(models.Model):
    id_pessoa = models.AutoField(primary_key=True)
    vinculo = models.CharField(max_length=20)
    id_user = models.ForeignKey(user, on_delete=models.CASCADE)
    cpf = models.IntegerField()
    nome = models.CharField(max_length=200)
    telefone = models.IntegerField(max_length=16)
    e_mail = models.EmailField()
    id_endereco = models.ForeignKey(enderecos, on_delete=models.CASCADE)
    id_conta = models.ForeignKey(contas, on_delete=models.CASCADE)

class ocorrencias(models.Model):
    id_ocorrencia = models.AutoField(primary_key=True)
    data = models.DateField(auto_now_add=True)
    realizada = models.IntegerField(max_length=1)
    ocorrencia = models.TextField()
    id_pessoa = models.ForeignKey(pessoas, on_delete=models.CASCADE)


